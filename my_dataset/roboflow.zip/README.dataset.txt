# Label Dataset > 2025-12-13 2:15pm
https://universe.roboflow.com/object-detection-0dvrp/label-dataset-os02m

Provided by a Roboflow user
License: CC BY 4.0

